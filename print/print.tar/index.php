﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Print - Imprimir</title>
<meta name="description" content="Descrição" />
<meta name="keywords" content="Palavras Chaves" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<style type="text/css" media="print">
#topo .menu, #rodape .menu, #conteudo_corpo .imprimir {display:none;}
#topo .info_imprimir {display:block; text-align:center; margin:5px;}
#conteudo_corpo .titulo{margin-bottom:5px; padding-bottom:5px; border-bottom:5px solid #999;}
#rodape {margin-top:5px; padding-top:5px; border-top:5px solid #999;}
</style>
<body>
<div id="corpo">
	<div id="topo">
    	<div class="logo">
        	<a href="index.php" title="Print - Imprimir | Home">
            	<img src="images/logo.png" border="0" alt="Logo" title="Print - Imprimir (Palavras Chaves)" width="480" height="109"/>
            </a>
        </div><!--/logo-->
        <div class="info_imprimir">Solicitação de Doação de Sofá. Para outros presentes acesse: http://bit.ly/raleval</div>
        <div class="linha"></div><!--/linha-->
        
       	<ul class="menu">
        	<li class="iconel"></li>
        	<li><a href="#" title="Print - Imprimir | Home">INICIO</a></li><li class="separador"></li>
            <li><a href="#" title="Print - Imprimir | Quem Somos">QUEM SOMOS</a></li><li class="separador"></li>
            <li><a href="#" title="Print - Imprimir | Portfolio">PORTFOLIO</a></li><li class="separador"></li>
            <li><a href="#" title="Print - Imprimir | Serviços">SERVIÇOS</a></li><li class="separador"></li>
            <li><a href="#" title="Print - Imprimir | Expediente">EXPEDIENTE</a></li><li class="separador"></li>
            <li><a href="#" title="Print - Imprimir | Fale Conosco">FALE CONOSCO</a></li>
            <li class="iconer"></li>
        </ul><!--/menu-->
        
    </div><!--/topo-->
    <div id="espaco"></div><!--/espaco-->
    <div id="conteudo">
    	<div id="conteudo_corpo">
        	<h1 class="titulo">Ral e Val - Presente do Mês: Sofá</h1>
            
            <div class="siderbar_a">
            	<div class="ref">
                	<h2>Conjunto Sofá de Canto - ZARA</h2>
                
                	<p>Mussum ipsum cacilds, vidis litro abertis. Consetis adipiscings elitis. Pra lá , depois divoltis porris, paradis. Paisis, filhis, espiritis santis. Mé faiz elementum girarzis, nisi eros vermeio, in elementis mé pra quem é amistosis quis leo. Manduma pindureta quium dia nois paga. Sapien in monti palavris qui num significa nadis i pareci latim. Interessantiss quisso pudia ce receita de bolis, mais bolis eu num gostis.</p>
					<ul>
                		<li>Suco de cevadiss, é um leite divinis, qui tem lupuliz, matis. </li>
	                	<li>Interagi no mé, cursus quis, vehicula ac nisi. Aenean vel dui dui.</li>
                		<li>Nullam leo erat, aliquet quis tempus a, posuere ut mi.</li>
                	</ul>
           
               		<p>Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Interagi no mé, cursus quis, vehicula ac nisi. Aenean vel dui dui.</p>
                
                	<span>R$ 2.490,00</span>
                
                	<div class="contato">
                		<span>Faça sua doação:</span>
                    	<p>Telefone: (41) 9709-0478 / Celular: (41) 9638-0199</p>
                    	<p>contato@raloliver.com</p>
                	</div><!--/contato-->
                
                </div><!--/ref-->
                
                <ul class="imagens">
                	<li><img src="midias/01.png" alt="Imagem da Doação" title="Sofá Zara" /></li>
                    <li><img src="midias/02.png" alt="Imagem da Doação" title="Sofá Zara" /></li>
                </ul>
                
            </div><!--/sidebar_a-->
            
            <div class="siderbar_b">
            	<div class="thumb"><img src="midias/03.png" alt="Imagem da Doação" title="Sofá Zara" /></div><!--/thumb-->
                
                <ul class="galeria">
                	<li><img src="midias/04.png" alt="Imagem da Doação" title="Sofá Zara" /></li>
                    <li><img src="midias/04.png" alt="Imagem da Doação" title="Sofá Zara" /></li>
                    <li><img src="midias/04.png" alt="Imagem da Doação" title="Sofá Zara" /></li>
                    <li><img src="midias/04.png" alt="Imagem da Doação" title="Sofá Zara" /></li>
                    <li><img src="midias/04.png" alt="Imagem da Doação" title="Sofá Zara" /></li>
                    <li><img src="midias/04.png" alt="Imagem da Doação" title="Sofá Zara" /></li>
                    <li><img src="midias/04.png" alt="Imagem da Doação" title="Sofá Zara" /></li>
                    <li><img src="midias/04.png" alt="Imagem da Doação" title="Sofá Zara" /></li>
                    <li><img src="midias/04.png" alt="Imagem da Doação" title="Sofá Zara" /></li>
                </ul><!--galeria-->
                
                	<div class="imprimir"><a href="javascript:self.print()">CLIQUE AQUI PARA DOAR!</a></div>
            </div><!--/sidebar_b-->
            
        </div><!--/conteudo_corpo-->
    </div><!--/conteudo-->
    
</div><!--/corpo-->
<div id="limpar"></div><!--limpar-->
<div id="rodape">
	<div class="rodape_corpo">
    	<div id="rodape_espaco"></div><!--/rodape_espaco-->
       	
        <ul class="menu">
        	<li class="iconel"></li>
        	<li><a href="#" title="Print - Imprimir | Home">INICIO</a></li><li class="separador"></li>
            <li><a href="#" title="Print - Imprimir | Quem Somos">QUEM SOMOS</a></li><li class="separador"></li>
            <li><a href="#" title="Print - Imprimir | Portfolio">PORTFOLIO</a></li><li class="separador"></li>
            <li><a href="#" title="Print - Imprimir | Serviços">SERVIÇOS</a></li><li class="separador"></li>
            <li><a href="#" title="Print - Imprimir | Expediente">EXPEDIENTE</a></li><li class="separador"></li>
            <li><a href="#" title="Print - Imprimir | Fale Conosco">FALE CONOSCO</a></li>
            <li class="iconer"></li>
        </ul><!--/menu-->
        
        <ul class="rodape_elementos">
        	<li>
            	<img src="images/logo_rodape.png" border="0" alt="Logo" title="Print - Imprimir (Palavras Chaves)" />
            </li>
            <li>
            	<div class="tel">Ligue:</div><!--/ligue-->
                <p>(41) 3153-1869</p>
                <p>(41) 3152-1869</p>
            </li>
            <li class="direita">
            	<div class="mail">Escreva:</div><!--/mail-->
                <p class="min">contato@raloliver.com</p>
                <p class="min">raloliver.ws@gmail.com</p>
            </li>
    </div><!--/rodape_corpo-->
</div><!--/rodape-->
</body>
</html>